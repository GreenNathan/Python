from flask import Flask

app = Flask(__name__)


# DATABASE = "oasddvb_db"

app.secret_key='funyan'
