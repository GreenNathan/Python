
from flask import render_template, redirect, session, request, flash
from flask_app import app
from flask_app.models.cars_model import Cars

@app.route('/show/<int:cars_id>')
def displayinfo():
    return redirect('/show.html')

@app.route('/show')
def show():
    return render_template('show.html')

@app.route('/edit')
def edit():
    return render_template('edit.html')

@app.route('/forsale')
def forsale():
    return render_template('forsale.html')

@app.route('/create', methods=['POST'])
def createcar():
    Cars.create(request.form)
    print(request.form)
    return redirect('/loggedin')

@app.route('/update', methods=['POST'])
def updatecar():
    Cars.update(request.form)
    print(request.form)
    return redirect('/loggedin')

@app.route('/delete/<int:id>')
def delete(id):
    # Cars.delete(car_id)
    print('deleted')
    return redirect('/loggedin')