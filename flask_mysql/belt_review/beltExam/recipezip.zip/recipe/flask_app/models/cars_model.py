
from flask_app.config.mysqlconnection import connectToMySQL


class Cars:
    def __init__(self, data):
        self.id = data['id']
        self.model= data['model']
        self.price = data ['price']
        self.make = data['make']
        self.year = data['year']
        self.description = data['description']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']
        self.users_id = data['users_id']

    @classmethod
    def create(cls, data):
        query = '''
                INSERT into cars (model, year, make, price, description, users_id)
                VALUES (%(model)s, %(year)s, %(make)s,
                %(description)s, %(users_id)s, %(price)s)
                '''
        return connectToMySQL('cardealz_db').query_db(query, data)

    @classmethod
    def update(cls,data):
        query = '''
                UPDATE cars 
                SET model= %(model)s, year= %(year)s,
                description= %(description)s WHERE id = %(id)s;
                '''
        return connectToMySQL('cardealz_db').query_db(query,data)
        return results


    @classmethod
    def get_one(cls, car_id):
        query = '''
                SELECT * FROM cars 
                WHERE id = %(id)s
                '''
        data = {'id': car_id}
        results = connectToMySQL('cardealz_db').query_db(query, data)
        return cls(results[0])

    @classmethod
    def delete(cls, car_id):
        query = '''
                DELETE FROM cars WHERE id = %(id)s;
                '''
        results = connectToMySQL('cardealz_db').query_db(query, {'id': car_id})
        return results